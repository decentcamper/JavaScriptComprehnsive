package com.ucsc.training.tutorial.scripting.core;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.security.auth.login.Configuration;
import javax.servlet.http.HttpServletRequest;

public class WebUtils {
	 public static final String LINE_BREAK = System.getProperty("line.separator");
	 public static boolean isPost(HttpServletRequest request) {
	        return request.getMethod().equalsIgnoreCase("POST");
	    }
	 
	 public static String getRequestPath(HttpServletRequest request) {
	        // / /EECentral/WEB-INF/ui/views/accounts/user-management/users.jsp
	        String uri = request.getRequestURI();
	        if (uri.indexOf("/WEB-INF/ui/views/") >= 0) {
	            uri = uri.substring(uri.indexOf("/WEB-INF/ui/views/") + 17).replaceFirst(".jsp", ".do");
	        } else {
	            uri = uri.replaceFirst(request.getContextPath(), "");
	        }
	        return uri;
	    }
	 public static Date getParameter(HttpServletRequest request, String paramName) {
	        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	        if (request != null && request.getParameterMap().containsKey(paramName)) {
	            String paramValue = request.getParameter(paramName);
	            if (!WebUtils.isNullOrEmpty(paramValue)) {
	                try {
	                    return dateFormat.parse(paramValue.toString());
	                } catch (ParseException e) {
	                    //logger.info("Error: While parsing the date - " + paramValue.toString() + "\n " + e.getMessage());
	                    return null;
	                }
	            }
	        }
	        return null;
	    }

	    public static String getParameter(HttpServletRequest request, String paramName, String defaultValue) {
	        if (request != null && request.getParameterMap().containsKey(paramName)) {
	            String paramValue = request.getParameter(paramName);
	            if (!WebUtils.isNullOrEmpty(paramValue)) {
	                return paramValue.toString();
	            }
	        }
	        return defaultValue;
	    }

	    public static Long getParameter(HttpServletRequest request, String paramName, Long defaultValue) {
	        if (request != null && request.getParameterMap().containsKey(paramName)) {
	            String paramValue = request.getParameter(paramName);
	            if (!WebUtils.isNullOrEmpty(paramValue)) {
	                try {
	                    return Long.parseLong(paramValue);
	                } catch (Exception e) {
	                    //logger.warn(" error while parsing parameter : " + paramName + "=" + paramValue + ", " + e.getMessage());
	                }
	                return defaultValue;
	            }
	        }
	        return defaultValue;
	    }

	    public static Double getParameter(HttpServletRequest request, String paramName, Double defaultValue) {
	    	if (request != null && request.getParameterMap().containsKey(paramName)) {
	    		String paramValue = request.getParameter(paramName);
	    		if (!WebUtils.isNullOrEmpty(paramValue)) {
	    			try {
	    				return Double.parseDouble(paramValue);
	    			} catch (Exception e) {
	    				//logger.warn(" error while parsing parameter : " + paramName + "=" + paramValue + ", " + e.getMessage());
	    			}
	    			return defaultValue;
	    		}
	    	}
	    	return defaultValue;
	    }
	    
	    public static Integer getParameter(HttpServletRequest request, String paramName, Integer defaultValue) {
	        if (request != null && request.getParameterMap().containsKey(paramName)) {
	            String paramValue = request.getParameter(paramName);
	            if (!WebUtils.isNullOrEmpty(paramValue)) {
	                try {
	                    return Integer.parseInt(paramValue);
	                } catch (Exception e) {
	                   // logger.warn(" error while parsing parameter : " + paramName + "=" + paramValue + ", " + e.getMessage());
	                }
	                return defaultValue;
	            }
	        }
	        return defaultValue;
	    }

	    public static Boolean getParameter(HttpServletRequest request, String paramName, Boolean defaultValue) {
	        if (request != null && request.getParameterMap().containsKey(paramName)) {
	            String paramValue = request.getParameter(paramName);
	            if (!WebUtils.isNullOrEmpty(paramValue)) {
	                try {
	                    return Boolean.parseBoolean(paramValue);
	                } catch (Exception e) {
	                    //logger.warn(" error while parsing parameter : " + paramName + "=" + paramValue + ", " + e.getMessage());
	                }
	                return defaultValue;
	            }
	        }
	        return defaultValue;
	    }

	    public static List<String> getParametersList(HttpServletRequest request, String paramName) {
	        if (request != null && request.getParameterMap().containsKey(paramName)) {
	            String[] paramValue = request.getParameterValues(paramName);
	            if (paramValue != null) {
	                List<String> paramValues = new ArrayList<String>();
	                try {
	                    for (Object value : paramValue) {
	                        paramValues.add((String) value);
	                    }
	                    return paramValues;
	                } catch (Exception e) {
	                    //logger.warn(" error while parsing parameter : " + paramName + "=" + paramValue + ", " + e.getMessage());
	                }
	                return Collections.emptyList();
	            }
	        }
	        return Collections.emptyList();
	    }

	    @Deprecated
	    public static List<? extends Object> getParametersList(HttpServletRequest request, String paramName, Class<?> clazz) {
	        if (request != null && request.getParameterMap().containsKey(paramName)) {
	            String[] paramValue = request.getParameterValues(paramName);
	            if (paramValue != null) {
	                List<Object> paramValues = new ArrayList<Object>();
	                try {
	                    for (Object value : paramValue) {

	                        paramValues.add(Class.forName(clazz.getName()).cast(value));
	                    }
	                    return paramValues;
	                } catch (Exception e) {
	                    //logger.warn(" error while parsing parameter : " + paramName + "=" + paramValue + ", " + e.getMessage());
	                }
	                // Add null check in the callee class
	                return null;//Collections.emptyList();
	            }
	        }
	        // Add null check in the callee class
	        return null;
	    }


	    public static Date parseDate(String date) {
	        throw new UnsupportedOperationException("needs to be implemented");
	    }

	    public static boolean isNullOrEmpty(String str) {
	        if (null == str || "".equals(str) || "null".equals(str)) {
	            return true;
	        }
	        return false;
	    }
	    
	    public static boolean isStringNullOrEmpty(String str) {
	    	if (null == str || "".equals(str.trim())) {
	    		return true;
	    	}
	    	return false;
	    }
	    
	    public static Set<Long> asLongList(HttpServletRequest request, String paramName) {
	        String parameterValue = WebUtils.getParameter(request, paramName, "");
	        if (parameterValue == null || "".equals(parameterValue)) {
	            return new TreeSet<Long>();
	        }

	        String[] tokens = parameterValue.split(",");
	        TreeSet<Long> list = new TreeSet<Long>();

	        for (String t : tokens) {
	            try {
	                long value = Long.parseLong(t);
	                list.add(value);
	            } catch (NumberFormatException e) {
	                // ignore has a bad token
	            }
	        }
	        return list;
	    }
	 
	
}
