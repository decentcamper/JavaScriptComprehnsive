package com.ucsc.training.tutorial.scripting.forms;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ucsc.training.tutorial.scripting.core.ServletUtilities;
import com.ucsc.training.tutorial.scripting.core.WebUtils;

/**
 * Servlet implementation class FirstFormHandler
 */
public class FirstFormHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FirstFormHandler() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String namestring = WebUtils.getParameter(request, "namestring", "");
		String comments =   WebUtils.getParameter(request, "comments", "");
		List<String> choice =    WebUtils.getParametersList(request, "choice");
		List<String> place =    WebUtils.getParametersList(request, "place");
		List<String> location =   WebUtils.getParametersList(request, "location");	
		
		String resultantChoices = "";
		String resultantplace = "";
		String resultantlocation  = "";
		if(location !=null && location.size() >0){
			for (String stringLocation : location){
				resultantlocation += " ";
				resultantlocation += stringLocation; 
				
				
			}	
			
		}
		if(choice !=null && choice.size() >0){
			for (String stringLocation : choice){
				resultantChoices += " ";
				resultantChoices += stringLocation; 
				
				
			}	
			
		}
		if(place !=null && place.size() >0){
			for (String stringLocation : place){
				resultantplace += " ";
				resultantplace += stringLocation; 
				
				
			}	
			
		}
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String title = "Reading Four Request Parameters";
		out.println(ServletUtilities.headWithTitle(title) +
	                "<BODY>\n" +
	                "<H1 ALIGN=CENTER>" + title + "</H1>\n" +
	                "<UL>\n" +
	                "  <LI>The name you entered: "   + namestring+ "\n" +
	                "  <LI>The comments you entered: " + comments + "\n" +
	                "  <LI>The choice you entered: " + resultantChoices + "\n" +
	                "  <LI>The places you entered: "  + resultantplace + "\n" + 
	                "  <LI>The location you entered: " + resultantlocation + "</UL>\n" + 
	                "</BODY></HTML>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String namestring = WebUtils.getParameter(request, "namestring", "");
		String comments =   WebUtils.getParameter(request, "comments", "");
		String action=  WebUtils.getParameter(request, "action", "");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		if(!WebUtils.isNullOrEmpty(action) && action.equalsIgnoreCase("onCLickHandler")){
			String name = WebUtils.getParameter(request, "name", "");
			String pass = WebUtils.getParameter(request, "pass", "");
			handleOnClickSubmission(name,pass,out);
			
			
		}
		if(!WebUtils.isNullOrEmpty(action) && action.equalsIgnoreCase("onSubmitHandler")){
			String name = WebUtils.getParameter(request, "name", "");
			String pass = WebUtils.getParameter(request, "pass", "");
			handleonSubmitSubmission(name,pass,out);
			
			
		}else{List<String> choice =    WebUtils.getParametersList(request, "choice");
		
		List<String> place =    WebUtils.getParametersList(request, "place");
		List<String> location =   WebUtils.getParametersList(request, "location");	
		
		String resultantChoices = "";
		String resultantplace = "";
		String resultantlocation  = "";
		if(location !=null && location.size() >0){
			for (String stringLocation : location){
				resultantlocation += " ";
				resultantlocation += stringLocation; 
				
				
			}	
			
		}
		if(choice !=null && choice.size() >0){
			for (String stringLocation : choice){
				resultantChoices += " ";
				resultantChoices += stringLocation; 
				
				
			}	
			
		}
		if(place !=null && place.size() >0){
			for (String stringLocation : place){
				resultantplace += " ";
				resultantplace += stringLocation; 
				
				
			}	
			
		}
		
		String title = "Reading Four Request Parameters";
		out.println(ServletUtilities.headWithTitle(title) +
	                "<BODY>\n" +
	                "<H1 ALIGN=CENTER>" + title + "</H1>\n" +
	                "<UL>\n" +
	                "  <LI>The name you entered: "   + namestring+ "\n" +
	                "  <LI>The comments you entered: " + comments + "\n" +
	                "  <LI>The choice you entered: " + resultantChoices + "\n" +
	                "  <LI>The places you entered: "  + resultantplace + "\n" + 
	                "  <LI>The location you entered: " + resultantlocation + "</UL>\n" + 
	                "</BODY></HTML>");
		}
		
		
	}

	private void handleonSubmitSubmission(String name, String pass,
			PrintWriter out) {
		String title = "Reading the Parameters From the OnSubmit Submission";
		out.println(ServletUtilities.headWithTitle(title) +
                "<BODY>\n" +
                "<H1 ALIGN=CENTER>" + title + "</H1>\n" +
                "<UL>\n" +
                "  <LI>The name you entered: "   + name+ "\n" +
                "  <LI>The password you entered: " + pass + "\n" +
                "</UL>\n" + 
                "</BODY></HTML>");
		
		
	}

	private void handleOnClickSubmission(String name, String pass, PrintWriter out) {
		String title = "Reading the Parameters From the OnClick Submission";
		out.println(ServletUtilities.headWithTitle(title) +
                "<BODY>\n" +
                "<H1 ALIGN=CENTER>" + title + "</H1>\n" +
                "<UL>\n" +
                "  <LI>The name you entered: "   + name+ "\n" +
                "  <LI>The password you entered: " + pass + "\n" +
                "</UL>\n" + 
                "</BODY></HTML>");
		
	}

}
