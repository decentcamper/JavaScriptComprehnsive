package com.ucsc.training.tutorial.scripting.forms;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.validator.GenericValidator;

import com.ucsc.training.tutorial.scripting.core.ServletUtilities;
import com.ucsc.training.tutorial.scripting.core.WebUtils;

/**
 * Servlet implementation class BackendValidator
 */
public class BackendValidator extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BackendValidator() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String username = WebUtils.getParameter(request, "username", "");
		String pwd = WebUtils.getParameter(request, "pwd", "");
		String email = WebUtils.getParameter(request, "email", "");
		String phone = WebUtils.getParameter(request, "phone", "");
		String from = WebUtils.getParameter(request, "from", "");
		boolean isEmail = GenericValidator.isEmail(WebUtils.getParameter(request, "email",""));
		boolean isPhone =  GenericValidator.matchRegexp(WebUtils.getParameter(request, "phone",""), "^\\(?([0-9]{3})\\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$");
		
		System.out.println(isEmail);
		System.out.println(isPhone);
		
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String title = "Reading Four Request Parameters";
		out.println(ServletUtilities.headWithTitle(title) +
	                "<BODY>\n" +
	                "<H1 ALIGN=CENTER>" + title + "</H1>\n" +
	                "<UL>\n" +
	                "  <LI>The Username that you entered is : "   + username+ "\n" +
	                "  <LI>The pwd you entered: " + pwd + "\n" +
	                "  <LI>The email you entered: " + email + "\n" +
	                "  <LI>The phone you entered: "  + phone + "\n" + 
	                "  <LI>The from you entered: "  + from + "\n" + 
	                "  <LI>Did the backend validation for the email succeed: "  + isEmail + "\n" + 
	                "  <LI>Did the backend validation for the phone succeed:  " + isPhone + "</UL>\n" + 
	                "</BODY></HTML>");
		
		
		
	}

}
